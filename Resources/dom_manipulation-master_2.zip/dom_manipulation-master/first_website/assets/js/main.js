console.log("I love my fellow learners");
// document.write("sylhet")


// const element = document.getElementById("my-id");

// // console.log(element.innerText);
// element.innerText = "We love my country";

// Example 1

// let myParagraph = document.getElementById("my-paragraph");
// myParagraph.innerHTML = `
// <p>We love our country</p>
// <span>this is our country</span>



// `


// Example 2

//  let myDiv = document.getElementById("my-div");
// myDiv.style.backgroundColor = "red";
// myDiv.style.color = "white";
 
// Example 3

// let myDiv = document.getElementById("my-div");
// let newParagraph = document.createElement("p");
// newParagraph.innerHTML = "This is a new paragraph.";
 
// newParagraph.style.color = "white";
// newParagraph.style.backgroundColor = "red";
// myDiv.appendChild(newParagraph);


// Example 4

// function test() {
//     myButton.innerHTML = "djafklsdk;fljasdfsadf";
// }

// var myButton = document.getElementById("my-button");
// myButton.addEventListener("click",test);


// Example 5
    // document.title = "Ostad mern 3";


// Example 6

// const myDiv = document.getElementById('myDiv');
// myDiv.style.backgroundColor = 'blue';
// myDiv.style.width = '200px';
// myDiv.style.height = '200px';

// Example 7

// const myDiv = document.getElementById('myDiv');
// myDiv.classList.remove('box');


// Example 8

//  const parent = document.getElementById('parent');
// const child = document.createElement('div');
//  child.textContent = 'This is a child element';
//  parent.appendChild(child);

// Example 9

// const child = document.getElementById('child');
//  child.parentNode.removeChild(child);


// Example 10

// const button = document.getElementById('myButton');
// button.addEventListener('click', () => {
//   alert('Button clicked!');
// });


// Example 11


// let myElement = document.getElementById("my-element");
// myElement.innerHTML = "<ul><li>Item 1</li><li>Item 2</li></ul>";
// myElement.innerHTML = `
// <li>Apple</li>
// <li>Orange</li>
// <li>Mango</li>
// `
