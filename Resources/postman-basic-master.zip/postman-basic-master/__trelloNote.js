/**
 * https://developer.atlassian.com/cloud/trello/guides/rest-api/api-introduction/#your-first-api-call
 * 
 * https://developer.atlassian.com/cloud/trello/rest/api-group-boards/#api-boards-id-memberships-get
 * 
 * https://developer.atlassian.com/cloud/trello/guides/rest-api/api-introduction/
 * 
 * 
 * */ 